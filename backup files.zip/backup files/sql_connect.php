<?php

$sql = mysqli_connect ("localhost", "root", "", "webportal");

if (!$sql){
	echo "Error connecting to database<br>";
}

?>
